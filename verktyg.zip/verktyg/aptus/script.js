// Verktyg Aptus

// Funktion för att konvertera hexadecimalt till decimalt
function hexToDec(hexString) {
    let decValue = BigInt("0x" + hexString);
    let decString = decValue.toString();
    return decString.substring(decString.length - 9);
}

// Visa felmeddelande
function showError() {
    const errorMessage = document.getElementById('errorMessage');
    if (errorMessage) {
        errorMessage.classList.add('show');
        errorMessage.style.display = 'block';

        setTimeout(function () {
            errorMessage.classList.remove('show');
            setTimeout(function () {
                errorMessage.style.display = 'none';
            }, 500);
        }, 3000);
    }
}

// Hantera klick på konverteringsknappen
document.getElementById('convertButton')?.addEventListener('click', function () {
    const hexValues = document.getElementById('hexInput').value.split('\n');
    const resultBody = document.getElementById('resultBody');
    let resultHTML = '';
    let isValidInput = true;
    let totalCount = 0;

    hexValues.forEach(function (hex) {
        if (hex.trim() !== '' && /^[0-9A-Fa-f]+$/.test(hex.trim())) {
            const decValue = hexToDec(hex.trim());
            resultHTML += `<tr><td>${hex}</td><td>${decValue}</td></tr>`;
            totalCount++;
        } else {
            isValidInput = false;
        }
    });

    if (!isValidInput) {
        showError();
    } else {
        resultBody.innerHTML = resultHTML;
        document.getElementById('exportButton').style.display = totalCount > 0 ? 'block' : 'none';
        document.getElementById('clearButton').style.display = totalCount > 0 ? 'block' : 'none';
    }
});

// Hantera klick på exportknappen
document.getElementById('exportButton')?.addEventListener('click', function () {
    let csvContent = "data:text/csv;charset=utf-8,Original EM,Aptus\r\n";
    const rows = document.querySelectorAll("#resultTable tr");

    rows.forEach(function (row) {
        const cols = row.querySelectorAll("td, th");
        const rowData = Array.from(cols, col => col.innerText).join(",");
        csvContent += rowData + "\r\n";
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "konverterade_varden.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
});

// Hantera temaväxling
document.getElementById('themeToggle')?.addEventListener('click', function () {
    const body = document.body;
    body.classList.toggle('dark-theme');
    const isDarkTheme = body.classList.contains('dark-theme');
    document.getElementById('sunIcon').style.display = isDarkTheme ? 'inline' : 'none';
    document.getElementById('moonIcon').style.display = isDarkTheme ? 'none' : 'inline';
});

// Hantera Enter-knapp för att konvertera
document.getElementById('hexInput')?.addEventListener('keydown', function (event) {
    if (event.key === 'Enter') {
        event.preventDefault();
        document.getElementById('convertButton').click();
    }
});

// Hantera klick på tillbakaknappen
document.getElementById('backButton')?.addEventListener('click', function () {
    window.location.href = 'https://mackan.eu/verktyg/';
});

// Hantera klick på rensaknappen
document.getElementById('clearButton')?.addEventListener('click', function () {
    document.getElementById('hexInput').value = '';
    document.getElementById('resultBody').innerHTML = '';
    document.getElementById('exportButton').style.display = 'none';
    document.getElementById('clearButton').style.display = 'none';
});

// Hantera klick på kopieringsknappen
document.getElementById('copyRightColumn')?.addEventListener('click', function () {
    const rows = document.querySelectorAll("#resultTable tr");
    let textToCopy = '';

    rows.forEach(function (row) {
        const cell = row.cells[1];
        if (cell) {
            textToCopy += cell.innerText + '\n';
        }
    });

    const tempTextArea = document.createElement('textarea');
    tempTextArea.value = textToCopy;
    document.body.appendChild(tempTextArea);
    tempTextArea.select();
    document.execCommand('copy');
    document.body.removeChild(tempTextArea);

    alert('Högra kolumnen kopierad till urklipp!');
});

// Hantera stängning av felmeddelande
document.getElementById('closeError')?.addEventListener('click', function () {
    const errorMessage = document.getElementById('errorMessage');
    errorMessage.classList.remove('show');
    setTimeout(function () {
        errorMessage.style.display = 'none';
    }, 500);
});

// Sätt versionnummer vid laddning
document.addEventListener('DOMContentLoaded', () => {
    const versionNumber = document.getElementById('versionNumber');
    if (versionNumber) {
        versionNumber.textContent = "2.4";
    }
});
