import customPaletteModule from './custom-palette.js';
import customTranslate from './custom-translate.js';

const modeler = new BpmnJS({
  container: '#canvas',
  additionalModules: [
    customPaletteModule,
    customTranslate
  ]
});

const createNewDiagram = async () => {
  const emptyDiagram = `
    <?xml version="1.0" encoding="UTF-8"?>
    <bpmn:definitions 
      xmlns:bpmn="http://www.omg.org/spec/BPMN/20100524/MODEL"
      xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI"
      xmlns:dc="http://www.omg.org/spec/DD/20100524/DC"
      id="Definitions_1">
      <bpmn:process id="Process_1" />
      <bpmndi:BPMNDiagram id="BPMNDiagram_1">
        <bpmndi:BPMNPlane id="BPMNPlane_1" bpmnElement="Process_1" />
      </bpmndi:BPMNDiagram>
    </bpmn:definitions>
  `;

  try {
    await modeler.importXML(emptyDiagram);
    modeler.get('canvas').zoom('fit-viewport');
  } catch (err) {
    console.error('Kunde inte skapa tomt diagram:', err);
  }
};

window.bpmnModeler = modeler;
createNewDiagram();
