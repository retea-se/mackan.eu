import translations from './sv-translations.js';

export default {
  __init__: ['customTranslate'],
  customTranslate: ['value', function () {
    return {
      translate(template, replacements) {
        const original = template;
        const translated = translations[template];

        if (translated) {
          console.log(`[översättning] "${original}" → "${translated}"`);
        } else {
          console.warn(`[saknas] "${original}" – ingen svensk översättning funnen`);
        }

        let output = translated || original;

        if (replacements) {
          Object.keys(replacements).forEach((key) => {
            output = output.replace(`{${key}}`, replacements[key]);
          });
        }

        return output;
      }
    };
  }]
};
