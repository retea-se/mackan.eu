export default {
    __init__: ['customPalette'],
    customPalette: ['type', function (palette, create, elementFactory, translate) {
      console.log('[v2] Initierar anpassad palett');
  
      palette.registerProvider({
        getPaletteEntries() {
          const label = translate('Lägg till: Min Uppgift');
          console.log(`[översättning] "Lägg till: Min Uppgift" → "${label}"`);
  
          const entries = {
            'create.custom-task': {
              group: 'model',
              className: 'bpmn-icon-task',
              title: label, // Korrekt: färdigöversatt text
              index: 999,
              action: {
                dragstart: (event) => {
                  console.log('[v2] Dra Min Uppgift');
                  const businessObject = window.bpmnModeler.get('moddle').create('bpmn:Task', {
                    name: 'Min Uppgift'
                  });
                  const shape = elementFactory.createShape({
                    type: 'bpmn:Task',
                    businessObject
                  });
                  create.start(event, shape);
                },
                click: (event) => {
                  console.log('[v2] Klickade: Min Uppgift');
                  const businessObject = window.bpmnModeler.get('moddle').create('bpmn:Task', {
                    name: 'Min Uppgift'
                  });
                  const shape = elementFactory.createShape({
                    type: 'bpmn:Task',
                    businessObject
                  });
                  create.start(event, shape);
                }
              }
            }
          };
  
          return entries;
        }
      });
    }]
  };
  