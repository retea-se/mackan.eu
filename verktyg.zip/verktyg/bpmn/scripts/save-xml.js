document.addEventListener('DOMContentLoaded', () => {
    console.log('[v3] Initierar exportfunktioner...');
  
    const svgButton = document.getElementById('svg-button');
    const pngButton = document.getElementById('png-button');
    const saveButton = document.getElementById('save-button');
    const pdfButton = document.getElementById('pdf-button');
  
    if (saveButton) {
      saveButton.addEventListener('click', async () => {
        try {
          const { xml } = await window.bpmnModeler.saveXML({ format: true });
          const blob = new Blob([xml], { type: 'application/xml' });
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = 'diagram.bpmn';
          a.click();
          URL.revokeObjectURL(url);
        } catch (err) {
          console.error('Sparfel:', err);
        }
      });
    }
  
    if (svgButton) {
      svgButton.addEventListener('click', async () => {
        try {
          const { svg } = await window.bpmnModeler.saveSVG();
          const blob = new Blob([svg], { type: 'image/svg+xml' });
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = 'diagram.svg';
          a.click();
          URL.revokeObjectURL(url);
        } catch (err) {
          console.error('SVG-exportfel:', err);
        }
      });
    }
  
    if (pngButton) {
      pngButton.addEventListener('click', async () => {
        try {
          const { svg } = await window.bpmnModeler.saveSVG();
          const img = new Image();
          const svgBlob = new Blob([svg], { type: 'image/svg+xml' });
          const url = URL.createObjectURL(svgBlob);
  
          img.onload = () => {
            const canvas = document.createElement('canvas');
            canvas.width = img.width;
            canvas.height = img.height;
            const ctx = canvas.getContext('2d');
            ctx.drawImage(img, 0, 0);
            URL.revokeObjectURL(url);
  
            canvas.toBlob(blob => {
              const pngUrl = URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = pngUrl;
              a.download = 'diagram.png';
              a.click();
              URL.revokeObjectURL(pngUrl);
            }, 'image/png');
          };
  
          img.src = url;
        } catch (err) {
          console.error('PNG-exportfel:', err);
        }
      });
    }
  
    if (pdfButton) {
        pdfButton.addEventListener('click', async () => {
          try {
            const { svg } = await window.bpmnModeler.saveSVG();
            const img = new Image();
            const svgBlob = new Blob([svg], { type: 'image/svg+xml' });
            const url = URL.createObjectURL(svgBlob);
      
            img.onload = () => {
              const { jsPDF } = window.jspdf;
              const pdf = new jsPDF({
                orientation: 'landscape',
                unit: 'mm',
                format: 'a3'
              });
      
              const pageWidth = pdf.internal.pageSize.getWidth();
              const pageHeight = pdf.internal.pageSize.getHeight();
      
              const canvas = document.createElement('canvas');
              canvas.width = img.width;
              canvas.height = img.height;
              const ctx = canvas.getContext('2d');
              ctx.drawImage(img, 0, 0);
      
              URL.revokeObjectURL(url);
              const imgData = canvas.toDataURL('image/png');
      
              // Beräkna skala som passar inom sidan (men aldrig skala upp)
              const scale = Math.min(
                1,
                (pageWidth - 20) / img.width,
                (pageHeight - 20) / img.height
              );
      
              const renderWidth = img.width * scale;
              const renderHeight = img.height * scale;
              const marginX = (pageWidth - renderWidth) / 2;
              const marginY = (pageHeight - renderHeight) / 2;
      
              pdf.addImage(imgData, 'PNG', marginX, marginY, renderWidth, renderHeight);
              pdf.save('diagram.pdf');
            };
      
            img.src = url;
          } catch (err) {
            console.error('PDF-exportfel:', err);
          }
        });
      }
  });