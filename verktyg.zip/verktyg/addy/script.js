function generateAddress() {
    var fromAddress = document.getElementById('fromAddress').value;
    var toAddress = document.getElementById('toAddress').value;

    var localPart = toAddress.split('@')[0];
    var domain = toAddress.split('@')[1];
    var generatedAddress = fromAddress.split('@')[0] + '+' + localPart + '=' + domain + '@' + fromAddress.split('@')[1];
    
    document.getElementById('generatedAddress').value = generatedAddress;
}

function copyToClipboard() {
    var copyText = document.getElementById("generatedAddress");
    copyText.select();
    document.execCommand("copy");
}

function toggleTheme() {
    document.body.classList.toggle('dark-theme');
}
let currentLanguage = 'sv';

const translations = {
    'sv': {
        'fromLabel': 'Från',
        'toLabel': 'Till',
        'resultLabel': 'Resultat',
        'generateButton': 'Generera Adress',
        'copyButton': 'Kopiera',
        'toggleThemeButton': 'Växla Tema',
        'toggleLanguageButton': 'Sv/En'
    },
    'en': {
        'fromLabel': 'From',
        'toLabel': 'To',
        'resultLabel': 'Result',
        'generateButton': 'Generate Address',
        'copyButton': 'Copy',
        'toggleThemeButton': 'Toggle Theme',
        'toggleLanguageButton': 'En/Sv'
    }
};

function toggleLanguage() {
    currentLanguage = currentLanguage === 'sv' ? 'en' : 'sv';

    document.getElementById('fromLabel').textContent = translations[currentLanguage].fromLabel;
    document.getElementById('toLabel').textContent = translations[currentLanguage].toLabel;
    document.getElementById('resultLabel').textContent = translations[currentLanguage].resultLabel;
    document.getElementById('generateButton').textContent = translations[currentLanguage].generateButton;
    document.getElementById('copyButton').textContent = translations[currentLanguage].copyButton;
    document.getElementById('themeToggle').textContent = translations[currentLanguage].toggleThemeButton;
    document.getElementById('languageToggle').textContent = translations[currentLanguage].toggleLanguageButton;
}

// Om du använder event listeners
document.addEventListener('DOMContentLoaded', (event) => {
    document.getElementById('languageToggle').addEventListener('click', toggleLanguage);
});
function goBack() {
    window.history.back();
}
